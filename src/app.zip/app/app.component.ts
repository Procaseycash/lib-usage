import {AfterViewInit, Component, OnInit} from '@angular/core';
import {EventsService} from "larang-paginator";
import {Http} from "@angular/http";
import 'rxjs/add/operator/map';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'app';
  public paginator = {
    path: 'http://api.dealin.io/v1/user', // 'http://localhost:8088/api/organizations',
    limit: 5,
    perNav: 5,
    data: null,
    from: 'list_organizations'

  };

  constructor(private eventsService: EventsService, private http: Http) {
    this.eventsService.on(this.paginator.from, (res) => {
      // pass response to the property rendering the data in view

      this.paginator.data = res; // update paginated data in view
    });
  }
  private getTransactions() {
    this.http.get(this.paginator.path + `?page=1&paginate=${this.paginator.limit}`)
      .map(res => res.json()).subscribe(
      (res) => {
        this.constructPaging(res);
        console.log('Response=', res);
      },
      (err) => {

      }
    );
  }

  /**
   * paging contructor.
   * @param res
   */
  constructPaging(res) {
    this.paginator.data =  {
      "total": res['meta']['total'],
      "per_page": res['meta']['perPage'],
      "current_page": res['meta']['page'],
      "last_page": res['meta']['pageCount'],
      "next_page_url": `${this.paginator.path}?page=` + res['meta']['nextPage'],
      "prev_page_url": (res['meta']['previousPage']) ? `${this.paginator.path}?page=`  + res['meta']['previousPage'] : null,
      "path": this.paginator.path,
      "from": res['meta']['perPage'],
      "to": res['meta']['total'],
      "data": res['data']
    };
  }

  ngOnInit() {
    this.getTransactions();
  }
  ngAfterViewInit() {
   // this.getTransactions();
  }
}
